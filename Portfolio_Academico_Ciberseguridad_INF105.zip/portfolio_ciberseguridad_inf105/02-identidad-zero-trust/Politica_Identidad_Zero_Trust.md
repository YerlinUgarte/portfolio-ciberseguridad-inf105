# Política básica de Identidad y Acceso – Laboratorio INF-105

## Objetivo
Reducir el riesgo de compromiso de cuentas mediante autenticación robusta, mínimo privilegio y baja oportuna de accesos.

## Estándar propuesto
- Contraseñas únicas, con longitud mínima recomendada de 14 caracteres y soporte de frases de paso.
- Gestor corporativo de contraseñas y bloqueo de contraseñas conocidas o filtradas.
- MFA preferente: FIDO2/passkeys. TOTP como alternativa; SMS no recomendado como factor principal.
- Sin caducidad periódica obligatoria salvo exigencia justificada; cambio inmediato ante compromiso o sospecha.
- Limitación de intentos, detección de patrones anómalos y alertas al equipo responsable.
- Cuenta estándar para uso diario y cuenta administrativa separada, con elevación temporal y auditada.
- Offboarding: deshabilitar identidad, revocar sesiones/tokens y retirar accesos a VPN, correo, SaaS y ERP en menos de una hora desde la baja notificada.

## Verificación
Revisar trimestralmente cuentas privilegiadas, métodos MFA, accesos externos, cuentas inactivas y evidencias de bajas. Registrar excepciones con responsable, justificación y fecha de caducidad.
