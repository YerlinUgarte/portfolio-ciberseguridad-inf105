# Checklist de Backup 3-2-1-1-0 y Hardening – INF-105

## Backup frente a ransomware
- [ ] 3 copias: original + dos respaldos.
- [ ] 2 soportes/tecnologías diferentes.
- [ ] 1 copia externa.
- [ ] 1 copia air-gap o inmutable, con credenciales/plano de administración separados.
- [ ] 0 errores en pruebas de restauración; verificar integridad y documentar RPO/RTO.

## Puestos Windows
- [ ] Actualizaciones automáticas y gestión centralizada de parches.
- [ ] Retirar administrador local de cuentas de uso diario.
- [ ] BitLocker con TPM y custodia segura de claves de recuperación.
- [ ] Bloqueo automático a los 5 minutos y control de USB.

## Dispositivos móviles
- [ ] PIN robusto (mínimo 6 dígitos) y biometría.
- [ ] MDM/UEM con bloqueo y borrado remoto.
- [ ] Separación de perfil laboral y personal.
- [ ] Restringir instalación de aplicaciones no autorizadas.

## Redes y acceso remoto
- [ ] WPA3 o WPA2-Enterprise; evitar claves compartidas.
- [ ] VLAN separada para invitados/transportistas.
- [ ] VPN corporativa en redes públicas.
- [ ] MFA para VPN, correo web y ERP.

## Evidencia
Adjuntar configuración/export de políticas, inventario, logs, resultados de pruebas y actas de restauración. No marcar controles como implantados sin evidencia verificable.
