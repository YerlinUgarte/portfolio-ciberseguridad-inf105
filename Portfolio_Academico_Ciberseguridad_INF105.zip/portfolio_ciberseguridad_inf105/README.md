# Portfolio académico de Ciberseguridad | INF-105
### Blue Team · SOC Nivel 1 · Gestión de riesgos · Hardening

> **Proyecto académico práctico.** Este repositorio reúne ejercicios de laboratorio realizados en el marco del módulo INF-105. Los escenarios son simulados y las recomendaciones se plantean con finalidad formativa; no representan una auditoría real ni certifican la seguridad de una organización.

## Perfil del proyecto
Portfolio de aprendizaje orientado a demostrar competencias iniciales de ciberseguridad defensiva:
- Identificación de activos, amenazas, vulnerabilidades e impactos.
- Aplicación de la tríada CID: confidencialidad, integridad y disponibilidad.
- Diseño de políticas de identidad, autenticación multifactor y mínimo privilegio.
- Resiliencia frente a ransomware mediante copias 3-2-1-1-0.
- Bastionado básico de puestos Windows, dispositivos móviles y redes.
- Evaluación inicial de riesgos y propuesta de salvaguardas técnicas y organizativas.

**Autor/a:** [TU NOMBRE Y APELLIDOS]  
**Formación:** INF-105 – Ciberseguridad  
**Enfoque:** Blue Team / SOC Nivel 1  
**Estado:** Resolución académica documentada; evidencias de ejecución pendientes de adjuntar cuando se completen en la plataforma.

## Resumen de laboratorios

| Laboratorio | Objetivo | Resultado documentado |
|---|---|---|
| LAB 1 – Riesgo y CID | Relacionar activos, amenazas, vulnerabilidades y pilares CID | 4 escenarios resueltos; 20/20 respuestas esperadas según clave de la plataforma |
| LAB 2 – Identidad y Zero Trust | Definir una política de contraseñas, MFA y privilegios | Política recomendada: longitud mínima 14, FIDO2/passkeys preferentes, cambio ante compromiso y offboarding rápido |
| LAB 3 – Backup y hardening | Evaluar resiliencia ante ransomware y controles de bastionado | Diseño 3-2-1-1-0 y checklist de 12 controles |
| LAB 4 – Auditoría inicial | Valorar tres activos de Transporte y Logística Sur S.L. | Riesgos inherentes propuestos: A1=25, A2=16, A3=20 (P×I) |

## LAB 1 – Análisis de riesgo y tríada CID
Se analizaron cuatro escenarios:
1. Pérdida de USB sin cifrar con datos de clientes: impacto principal en **confidencialidad**; control preventivo: cifrado del soporte.
2. Corte eléctrico del servidor ERP sin SAI: impacto en **disponibilidad**; control preventivo: SAI y apagado controlado.
3. Alteración no autorizada de tarifas: impacto en **integridad**; controles detectivos: auditoría, trazabilidad y alertas.
4. Acceso de un exempleado con cuenta activa: impacto en **confidencialidad**; actuación correctiva inmediata: deshabilitar cuenta, revocar sesiones/tokens y revisar actividad.

## LAB 2 – Identidad, MFA y Zero Trust
Configuración propuesta:
- Longitud mínima de 14 caracteres y posibilidad de utilizar frases de paso largas.
- FIDO2/passkeys como opción preferente resistente al phishing; TOTP como alternativa. Evitar SMS como factor principal.
- No imponer rotación periódica arbitraria; cambiar credenciales ante compromiso o sospecha.
- Limitar intentos de autenticación y alertar ante patrones de fuerza bruta.
- Separar cuentas estándar y administrativas; aplicar mínimo privilegio.
- Gestor corporativo de contraseñas, credenciales únicas y comprobación frente a contraseñas filtradas.
- Revocar cuentas, sesiones, tokens y accesos al producirse una baja.

## LAB 3 – Resiliencia y bastionado
La estrategia de backup aplica:
- **3** copias de los datos.
- **2** tipos de soporte diferentes.
- **1** copia externa.
- **1** copia aislada (air-gap) o inmutable.
- **0** errores detectados en pruebas periódicas de restauración.

Checklist de hardening:
- Windows: parcheado, retirada de administrador local, BitLocker con TPM, bloqueo automático y control de USB.
- Móviles: PIN robusto/biometría, MDM y borrado remoto, separación de perfil laboral y bloqueo de aplicaciones no autorizadas.
- Redes: WPA3 o WPA2-Enterprise, segmentación de invitados, VPN en redes públicas y MFA para VPN/correo/ERP.

## LAB 4 – Auditoría inicial de Transporte y Logística Sur S.L.
Escenario académico de una empresa ficticia de 38 empleados. La puntuación utiliza la escala propuesta en la actividad: **Riesgo inherente = Probabilidad × Impacto**.

| Activo | P | I | P×I | Prioridad propuesta |
|---|---:|---:|---:|---|
| A1 – Ordenadores Windows | 5 | 5 | **25** | Muy alta |
| A2 – Móviles corporativos | 4 | 4 | **16** | Alta |
| A3 – Wi-Fi y acceso remoto | 5 | 4 | **20** | Alta |

**Salvaguardas principales**
- A1 técnica: gestión centralizada de parches, cuentas estándar, BitLocker, EDR y backup inmutable/offline. Organizativa: política de parcheado y uso aceptable.
- A2 técnica: MDM/UEM, cifrado, PIN/biometría, bloqueo y borrado remoto. Organizativa: notificación de pérdida en menos de una hora y compromiso de custodia.
- A3 técnica: VLAN separadas, WPA3/WPA2-Enterprise, VPN, MFA, firewall y monitorización. Organizativa: norma de movilidad/teletrabajo y prohibición de compartir claves.

> Las puntuaciones son una valoración inicial del caso didáctico. Los umbrales exactos de clasificación deben ajustarse a la plantilla Modelo A facilitada por el curso. No se calcula riesgo residual sin evidencias de implantación y eficacia de los controles.

## Evidencias y trazabilidad
La documentación se acompaña de:
- `01-auditoria-riesgos-pyme/Matriz_Riesgos_INF105_completada.xlsx`
- `02-identidad-zero-trust/Politica_Identidad_Zero_Trust.md`
- `03-resiliencia-hardening/Checklist_Backup_Hardening.md`
- `04-evidencias/` para capturas de la plataforma, resultados de simulación y pruebas de restauración.

**Pendiente de completar por el alumno/a:** añadir capturas propias de los cuatro laboratorios, nombre real, fecha de realización y, si procede, la plantilla Excel oficial cumplimentada. No se deben presentar capturas o pruebas no realizadas.

## Tecnologías y marcos de referencia
Conceptos trabajados: Windows/BitLocker, MFA, FIDO2, MDM, VPN, segmentación de red, copias inmutables, SIEM/alertas, mínimo privilegio, CID y análisis P×I. La actividad hace referencia a buenas prácticas CCN-CERT, NIST y MAGERIT; este portfolio no constituye una certificación ni una auditoría de conformidad.

## Declaración de alcance
Todos los escenarios son simulados y se utilizan exclusivamente con fines educativos. No se han realizado pruebas sobre sistemas de terceros ni se afirma haber implantado los controles propuestos en una organización real.
