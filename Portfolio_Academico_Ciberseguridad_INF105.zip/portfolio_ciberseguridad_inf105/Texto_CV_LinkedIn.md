# Texto para CV y LinkedIn

## CV – Proyecto académico
**Proyecto académico | Ciberseguridad defensiva (INF-105) – Blue Team / SOC Nivel 1**
- Análisis de escenarios de riesgo aplicando la tríada CID y relación amenaza-vulnerabilidad-impacto.
- Diseño de una política básica de identidad con MFA, FIDO2, mínimo privilegio y proceso de offboarding.
- Definición de una estrategia de copias 3-2-1-1-0 y checklist de hardening para Windows, movilidad y redes.
- Elaboración de una matriz inicial P×I y propuesta de salvaguardas técnicas y organizativas para una pyme ficticia.

## LinkedIn – Publicación
He documentado un proyecto académico de ciberseguridad defensiva dentro del módulo INF-105, con cuatro laboratorios centrados en análisis de riesgos, identidad y MFA, resiliencia frente a ransomware y bastionado técnico.

El trabajo incluye una matriz inicial de riesgos, una política básica de identidad y un checklist de controles preventivos. Los escenarios son simulados y las propuestas se presentan como ejercicios formativos de Blue Team / SOC Nivel 1.

#Ciberseguridad #BlueTeam #SOC #GestiónDeRiesgos #Hardening #ZeroTrust
